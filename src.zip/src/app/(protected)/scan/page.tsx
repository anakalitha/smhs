export default function ScanDashboard() {
  return (
    <div className="p-6">
      <h1 className="text-xl font-semibold">Scan Dashboard</h1>
      <p className="text-gray-600 mt-2">Placeholder for now.</p>
    </div>
  );
}
